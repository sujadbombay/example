# Service: Authorization 

### Purpose of the service:
Will be provided here

### Endpoint specification:
All endpoints will be described here

### Deployment Steps:
Deployment steps will be described here

### Project Contacts
Project contact emails will be provided here
