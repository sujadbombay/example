package com.relias.authorization.enums;

public enum Language {
    en,
    es
}
