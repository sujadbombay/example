package com.relias.authorization.rest;

import com.relias.authorization.entity.Authorization;
import com.relias.authorization.rest.dto.APIResponseData;
import com.relias.authorization.rest.dto.APIResponseDataList;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@RestController
@Slf4j
class AuthorizationController {

    private final AtomicInteger testGauge;
    private final Counter testCounter;

    private final com.relias.authorization.servie.CustomerAuthorizationService transactionService;

    private AuthorizationController(com.relias.authorization.servie.CustomerAuthorizationService customerAuthorizationService,
                                    MeterRegistry meterRegistry) {
        this.testGauge = meterRegistry.gauge("create_transaction", new AtomicInteger(0));
        this.testCounter = meterRegistry.counter("custom_counter");
        this.transactionService = customerAuthorizationService;
    }

    @PostMapping("/authorization")
    private ResponseEntity<APIResponseData<Authorization>> save(@RequestBody Authorization authorization) {
        log.debug("Request for authorization received {}", authorization);
        Authorization savedTransaction = transactionService.saveTransaction(authorization);

        testGauge.set(savedTransaction.getId().intValue());
        testCounter.increment();

        APIResponseData<Authorization> response = new APIResponseData<>();
        response.setSuccess(true);
        response.setData(savedTransaction);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/authorization")
    private List<Authorization> all() {
        return transactionService.getAll();
    }


    @GetMapping("/authorization/{customerId}")
    private ResponseEntity<APIResponseDataList<Authorization>> getTransactionById(@PathVariable String customerId) {
        log.debug("Request transaction received with parameter customer Id {}", customerId);
        List<Authorization> transactions = transactionService.getTransactionById(customerId);
        APIResponseDataList<Authorization> response = new APIResponseDataList<>();
        response.setSuccess(true);
        response.setData(transactions);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/authorization/{customerId}")
    private void deleteTransactionById(@PathVariable String customerId) {
        log.debug("Delete request transaction received with parameter customer Id {}", customerId);
        transactionService.deleteTransactionById(customerId);
    }
}