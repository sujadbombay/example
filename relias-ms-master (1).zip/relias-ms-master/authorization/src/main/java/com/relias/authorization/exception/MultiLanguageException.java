package com.relias.authorization.exception;

import com.relias.authorization.enums.Language;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MultiLanguageException extends RuntimeException {
    protected Language language;

    public MultiLanguageException(String message) {
        super(message);
    }
}
