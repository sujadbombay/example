package com.relias.authorization.repository;

import com.relias.authorization.entity.Authorization;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuthorizationRepository extends JpaRepository<Authorization, Long> {
    List<Authorization> findByCustomerId(String customerId);

    void deleteByCustomerId(String customerId);
}
