package com.relias.authorization.servie;

import com.relias.authorization.entity.Authorization;
import com.relias.authorization.exception.EntityNotFoundException;
import com.relias.authorization.repository.AuthorizationRepository;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.transaction.Transactional;
import java.util.List;

import static com.relias.authorization.rest.dto.ErrorCode.CUSTOMER_AUTHORIZATION_NOT_FOUND;

@Service
@Transactional
public class CustomerAuthorizationService {

    private AuthorizationRepository authorizationRepository;

    public CustomerAuthorizationService(AuthorizationRepository authorizationRepository) {
        this.authorizationRepository = authorizationRepository;
    }

    public Authorization saveTransaction(Authorization transaction) {
        return authorizationRepository.save(transaction);
    }

    public List<Authorization> getAll() {
        return authorizationRepository.findAll();
    }

    public List<Authorization> getTransactionById(String customerId) {
        List<Authorization>  transactions = authorizationRepository.findByCustomerId(customerId);
        if(CollectionUtils.isEmpty(transactions)){
            throw new EntityNotFoundException(CUSTOMER_AUTHORIZATION_NOT_FOUND, customerId);
        }

        return transactions;
    }

    public void deleteTransactionById(String customerId) {
        authorizationRepository.deleteByCustomerId(customerId);
    }
}
