package com.relias.authorization.rest.dto;

public enum ErrorCode {
    CUSTOMER_AUTHORIZATION_NOT_FOUND,
    SERVER_ERROR
}
