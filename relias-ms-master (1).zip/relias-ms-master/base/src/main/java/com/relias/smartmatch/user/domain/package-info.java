/**
 * JPA domain objects.
 */
package com.relias.smartmatch.user.domain;
