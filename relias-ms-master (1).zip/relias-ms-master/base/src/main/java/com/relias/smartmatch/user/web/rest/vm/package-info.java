/**
 * View Models used by Spring MVC REST controllers.
 */
package com.relias.smartmatch.user.web.rest.vm;
