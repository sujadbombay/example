/**
 * Spring Data JPA repositories.
 */
package com.relias.smartmatch.user.repository;
