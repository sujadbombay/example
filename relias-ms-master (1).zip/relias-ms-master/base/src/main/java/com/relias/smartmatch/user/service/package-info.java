/**
 * Service layer beans.
 */
package com.relias.smartmatch.user.service;
