# Service: Example Template

### Purpose of the service:
Purpose of this service is to present example endpoints that could be followed for all microservices. Like exception management, error response, endpoint request and responses.

### Endpoint specification:
All endpoints will be described here

### Deployment Steps:
Deployment steps will be described here

### Project Contacts
Project contact emails will be provided here