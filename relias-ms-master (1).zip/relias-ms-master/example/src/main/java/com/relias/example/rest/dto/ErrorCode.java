package com.relias.example.rest.dto;

public enum ErrorCode {
    CUSTOMER_TRANSACTIONS_NOT_FOUND,
    SERVER_ERROR
}
