package com.relias.example.enums;

public enum Language {
    en,
    es
}
